(* GRADE:  100% *)
let square x =
  x*x;;

let perimeter r =
  let pi=3.1415927 in r*.2.00*.pi;;

let div n m =
  float_of_int n /. float_of_int m;;  



